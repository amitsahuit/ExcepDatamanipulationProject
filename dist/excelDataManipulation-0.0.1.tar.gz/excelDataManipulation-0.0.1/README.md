## There are 2 ways to setup this project

## 1. create venv and install packages from requirements.txt file and rum main.py file.
```
git init
git clone 
py -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
py main.py
```

## 2. Direct whl file installation and import module in main.py and execute
```
pip install excelDataManipulation-0.0.1-py3-none-any.whl
py main.py
```


