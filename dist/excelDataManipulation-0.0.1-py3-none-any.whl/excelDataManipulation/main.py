from ConvertData import convertData
convertData('.//sampleInOutFiles//InpFile.xlsx','.//sampleInOutFiles//OptFile.xlsx')